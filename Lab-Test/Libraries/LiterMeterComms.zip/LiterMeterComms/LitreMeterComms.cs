﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTD2XX_NET;
using System.Timers;
using System.Threading;

namespace SMartEquipment.LitreMeter
{
    public class LitreMeterComms
    {
        enum ControlStep
        {
            cs_Initialising,
            cs_WaitingtoOpenPort,
            cs_WaitingForModelNumber,
            cs_WaitingForModelSuffix,
            cs_WaitingForSerialNumber,
            cs_WaitingForFirmwareVersion,
            cs_WaitingForFlow,
        };

        ControlStep m_controlStep;
        const byte m_modbusReadHoldingRegisterFunction = 3;
        const ushort m_flowRateRegisterIndex = 572;
        const ushort m_modelNumberRegisterIndex = 160;
        const ushort m_modelSuffixRegisterIndex = 173;
        const ushort m_firmwareVersionRegisterIndex = 162;
        const ushort m_serialNumberRegisterIndex = 165;

        bool m_newValueReceived;
        FTDI ftdi;
        List<byte> m_receivedPacket;
        System.Timers.Timer m_timer;

        byte m_address;
        ushort m_requestedRegisterIndex;

        uint m_expectedReplyLength;
        string m_FtdiSerialNumber = "LITREMETER1";
        float m_receivedflow;
        System.Diagnostics.Stopwatch m_stopwatch;
        bool m_InTimerEventHandler;
        int m_commsRetryCount;

        string m_literMeterModelNumber;
        string m_literMeterModelSuffix;
        string m_literMeterSerialNumber;
        string m_literMeterFirmwareVersion;

        public LitreMeterComms()
        {
            m_controlStep = ControlStep.cs_Initialising;
            m_receivedflow = float.NaN;
            m_address = 10;
            m_expectedReplyLength = 0;
            m_stopwatch = new System.Diagnostics.Stopwatch();

            ftdi = new FTDI();
            m_receivedPacket = new List<byte>();

            m_InTimerEventHandler = false;
            m_commsRetryCount = 0;

            m_literMeterModelNumber = "";
            m_literMeterModelSuffix = "";
            m_literMeterSerialNumber = "";
            m_literMeterFirmwareVersion = "";
        }

        public float GetFlow()
        {
            if (ftdi.IsOpen)
                return m_receivedflow;
            else return float.NaN;
        }
        //-- Opens comms port for supplied FTDI cable serial number and checks configuration
        public bool OpenPort(String strCableSerialNumber)
        {
            m_FtdiSerialNumber = strCableSerialNumber;
            if (ftdi.IsOpen) ftdi.Close();
            if (ftdi.OpenBySerialNumber(strCableSerialNumber) == FTDI.FT_STATUS.FT_OK)
            {
                if (ftdi.SetBaudRate(9600) == FTDI.FT_STATUS.FT_OK)
                {
                    if (ftdi.SetDataCharacteristics(FTDI.FT_DATA_BITS.FT_BITS_8, FTDI.FT_STOP_BITS.FT_STOP_BITS_2, FTDI.FT_PARITY.FT_PARITY_NONE) == FTDI.FT_STATUS.FT_OK)
                    {
                        if (ftdi.SetRTS(true) == FTDI.FT_STATUS.FT_OK)
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }
        public void ClosePort()
        {
            m_receivedflow = float.NaN;
            m_literMeterModelNumber = "";
            m_literMeterModelSuffix = "";
            m_literMeterSerialNumber = "";
            m_literMeterFirmwareVersion = "";
            ftdi.Close();
        }
        //-- Confirms the device is connected by getting the serial number
        public string GetDeviceIdentifier()
        {
            return "Litre Meter F" + m_literMeterModelNumber + "-" + m_literMeterModelSuffix + " SN" + m_literMeterSerialNumber + " FW V" + m_literMeterFirmwareVersion;
        }
        //-- Starts the communications engine 
        public bool InitiateCommunications()
        {
            if (string.IsNullOrEmpty(m_literMeterFirmwareVersion))
            {
                m_controlStep = ControlStep.cs_Initialising;
                m_timer = new System.Timers.Timer();
                m_timer.Interval = 100;
                m_timer.Enabled = true;
                m_timer.Elapsed += OnTimedEvent;

                UInt16 uiLoopCount = 100;
                while (string.IsNullOrEmpty(m_literMeterFirmwareVersion) && uiLoopCount > 0)
                {
                    Thread.Sleep(50);
                    uiLoopCount--;
                }
                if (uiLoopCount > 0) return true;
                else return false;
            }
            return true;
        }

        public bool SendRequestForDoubleRegister(byte modbusAddress, ushort registerIndex)
        {
            m_requestedRegisterIndex = registerIndex;
            m_expectedReplyLength = 9;

            List<byte> data = new List<byte>();

            // start register as requested
            data.Add((byte)(registerIndex >> 8));
            data.Add((byte)(registerIndex));

            // 2 16 bit registers
            data.Add(0);
            data.Add(2);

            // read holding registers
            return SendRequest(modbusAddress, m_modbusReadHoldingRegisterFunction, ref data);
        }

        public bool SendRequestForSingleRegister(byte modbusAddress, ushort registerIndex)
        {
            m_requestedRegisterIndex = registerIndex;
            m_expectedReplyLength = 7;

            List<byte> data = new List<byte>();

            // start register as requested
            data.Add((byte)(registerIndex >> 8));
            data.Add((byte)(registerIndex));

            // 1 16 bit register
            data.Add(0);
            data.Add(1);

            // read holding registers
            return SendRequest(modbusAddress, m_modbusReadHoldingRegisterFunction, ref data);
        }

        ushort CalculateModbusCrc(ref List<byte> data)
        {
            int len = data.Count();
            ushort crc = 0xFFFF;

            for (int pos = 0; pos < len; pos++)
            {
                crc ^= (ushort)(data[pos]);          // XOR byte into least sig. byte of crc

                for (int i = 8; i != 0; i--)
                {    // Loop over each bit
                    if ((crc & 0x0001) != 0)
                    {      // If the LSB is set
                        crc >>= 1;                    // Shift right and XOR 0xA001
                        crc ^= 0xA001;
                    }
                    else                            // Else LSB is not set
                        crc >>= 1;                    // Just shift right
                }
            }
            // Note, this number has low and high bytes swapped, so use it accordingly (or swap bytes)
            return crc;
        }

        bool SendRequest(byte modbusAddress, byte function, ref List<byte> data)
        {
            m_receivedPacket.Clear();

            List<byte> packet = new List<byte>();

            packet.Add(modbusAddress);
            packet.Add(function);
            for (int i = 0; i < data.Count(); ++i)
            {
                packet.Add(data[i]);
            }
            ushort crc = CalculateModbusCrc(ref packet);

            // CRC is transmitted low byte, high byte that is opposite to data
            packet.Add((byte)(crc & 0xFF));
            packet.Add((byte)((crc >> 8) & 0xFF));

            byte[] expandedData = packet.ToArray();
            int numExpandedBytes = packet.Count();

            uint numBytesWritten = 0;

            m_receivedPacket.Clear();
            if (ftdi.Write(expandedData, numExpandedBytes, ref numBytesWritten) != FTDI.FT_STATUS.FT_OK)
            {
                return false;
            }
            else if (numBytesWritten != numExpandedBytes)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        void ProcessRXBuffer(ref List<byte> packetData)
        {
            byte address = packetData[0];
            byte function = packetData[1];
            byte count = packetData[2];

            switch (m_requestedRegisterIndex)
            {
                case LitreMeterComms.m_flowRateRegisterIndex:
                    {
                        byte[] bytes = new byte[4];
                        bytes[3] = packetData[3];
                        bytes[2] = packetData[4];
                        bytes[1] = packetData[5];
                        bytes[0] = packetData[6];

                        float value = BitConverter.ToInt32(bytes, 0);

                        m_receivedflow = value / 100.0F;
                        m_newValueReceived = true;
                    }
                    break;
                case LitreMeterComms.m_modelNumberRegisterIndex:
                    {
                        byte[] bytes = new byte[2];
                        bytes[1] = packetData[3];
                        bytes[0] = packetData[4];

                        ushort value = BitConverter.ToUInt16(bytes, 0);

                        m_literMeterModelNumber = value.ToString();
                        m_newValueReceived = true;
                    }
                    break;
                case LitreMeterComms.m_modelSuffixRegisterIndex:
                    {
                        m_literMeterModelSuffix = ((char)packetData[4]).ToString();
                        m_newValueReceived = true;
                    }
                    break;
                case LitreMeterComms.m_firmwareVersionRegisterIndex:
                    {
                        byte[] bytes = new byte[4];
                        bytes[3] = packetData[3];
                        bytes[2] = packetData[4];
                        bytes[1] = packetData[5];
                        bytes[0] = packetData[6];

                        uint value = BitConverter.ToUInt32(bytes, 0);
                        string stringValueWithoutDecimalPoints = value.ToString();
                        stringValueWithoutDecimalPoints = ("000000" + stringValueWithoutDecimalPoints).Substring(stringValueWithoutDecimalPoints.Length, 6);

                        m_literMeterFirmwareVersion = stringValueWithoutDecimalPoints.Substring(0, 2) + "." + stringValueWithoutDecimalPoints.Substring(2, 2) + "." + stringValueWithoutDecimalPoints.Substring(4, 2);
                        m_newValueReceived = true;
                    }
                    break;
                case LitreMeterComms.m_serialNumberRegisterIndex:
                    {
                        byte[] bytes = new byte[4];
                        bytes[3] = packetData[3];
                        bytes[2] = packetData[4];
                        bytes[1] = packetData[5];
                        bytes[0] = packetData[6];

                        UInt32 value = BitConverter.ToUInt32(bytes, 0);

                        m_literMeterSerialNumber = value.ToString();
                        m_newValueReceived = true;
                    }
                    break;
            }
        }
        private void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            if (!m_InTimerEventHandler)
            {
                m_InTimerEventHandler = true;
                switch (m_controlStep)
                {
                    case ControlStep.cs_Initialising:
                        m_controlStep = ControlStep.cs_WaitingtoOpenPort;
                        m_stopwatch.Restart();
                        break;
                    case ControlStep.cs_WaitingtoOpenPort:
                        if (m_stopwatch.ElapsedMilliseconds > 500)
                        {
                            if (OpenPort(m_FtdiSerialNumber))
                            {
                                m_newValueReceived = false;
                                if (SendRequestForSingleRegister(m_address, m_modelNumberRegisterIndex))
                                {
                                    m_stopwatch.Restart();
                                    m_controlStep = ControlStep.cs_WaitingForModelNumber;
                                    m_commsRetryCount = 0;
                                }
                                else
                                {
                                    m_stopwatch.Restart();
                                    ClosePort();
                                }
                            }
                            else
                            {
                                // failed to open port
                                m_stopwatch.Restart();
                            }
                        }
                        break;

                    case ControlStep.cs_WaitingForModelNumber:
                        ProcessReceivedBytes();
                        if (m_newValueReceived)
                        {
                            m_commsRetryCount = 0;
                            m_newValueReceived = false;
                            if (SendRequestForSingleRegister(m_address, m_modelSuffixRegisterIndex))
                            {
                                m_stopwatch.Restart();
                                m_controlStep = ControlStep.cs_WaitingForModelSuffix;
                            }
                            else
                            {
                                ClosePort();
                                m_controlStep = ControlStep.cs_Initialising;
                            }
                        }
                        else if (m_stopwatch.ElapsedMilliseconds > 500)
                        {
                            ClosePort();
                        }
                        break;

                    case ControlStep.cs_WaitingForModelSuffix:
                        ProcessReceivedBytes();
                        if (m_newValueReceived)
                        {
                            m_commsRetryCount = 0;
                            m_newValueReceived = false;
                            if (SendRequestForDoubleRegister(m_address, m_serialNumberRegisterIndex))
                            {
                                m_stopwatch.Restart();
                                m_controlStep = ControlStep.cs_WaitingForSerialNumber;
                            }
                            else
                            {
                                ClosePort();
                                m_controlStep = ControlStep.cs_Initialising;
                            }
                        }
                        else if (m_stopwatch.ElapsedMilliseconds > 500)
                        {
                            ClosePort();
                        }
                        break;

                    case ControlStep.cs_WaitingForSerialNumber:
                        ProcessReceivedBytes();
                        if (m_newValueReceived)
                        {
                            m_commsRetryCount = 0;
                            m_newValueReceived = false;
                            if (SendRequestForDoubleRegister(m_address, m_firmwareVersionRegisterIndex))
                            {
                                m_stopwatch.Restart();
                                m_controlStep = ControlStep.cs_WaitingForFirmwareVersion;
                            }
                            else
                            {
                                ClosePort();
                                m_controlStep = ControlStep.cs_Initialising;
                            }
                        }
                        else if (m_stopwatch.ElapsedMilliseconds > 500)
                        {
                            ClosePort();
                        }
                        break;

                    case ControlStep.cs_WaitingForFirmwareVersion:
                        ProcessReceivedBytes();
                        if (m_newValueReceived)
                        {
                            m_commsRetryCount = 0;
                            m_newValueReceived = false;
                            if (SendRequestForDoubleRegister(m_address, m_flowRateRegisterIndex))
                            {
                                m_stopwatch.Restart();
                                m_controlStep = ControlStep.cs_WaitingForFlow;
                            }
                            else
                            {
                                ClosePort();
                                m_controlStep = ControlStep.cs_Initialising;
                            }
                        }
                        else if (m_stopwatch.ElapsedMilliseconds > 500)
                        {
                            ClosePort();
                        }
                        break;

                    case ControlStep.cs_WaitingForFlow:
                        ProcessReceivedBytes();
                        if (m_newValueReceived)
                        {
                            m_commsRetryCount = 0;
                            m_newValueReceived = false;
                            if (SendRequestForDoubleRegister(m_address, m_flowRateRegisterIndex))
                            {
                                m_stopwatch.Restart();
                                m_controlStep = ControlStep.cs_WaitingForFlow;
                            }
                            else
                            {
                                ClosePort();
                                m_controlStep = ControlStep.cs_Initialising;
                            }
                        }
                        else if (m_stopwatch.ElapsedMilliseconds > 500)
                        {
                            ++m_commsRetryCount;
                            if (m_commsRetryCount > 3)
                            {
                                ClosePort();
                                m_controlStep = ControlStep.cs_Initialising;
                            }
                            else
                            {
                                if (SendRequestForDoubleRegister(m_address, m_flowRateRegisterIndex))
                                {
                                    m_stopwatch.Restart();
                                    m_controlStep = ControlStep.cs_WaitingForFlow;
                                }
                            }
                        }
                        break;
                }
                m_InTimerEventHandler = false;
            }
        }

        void ProcessReceivedBytes()
        {
            uint rxDataAvailable = 0;
            if (ftdi.GetRxBytesAvailable(ref rxDataAvailable) == FTDI.FT_STATUS.FT_OK)
            {
                byte[] dataBuffer = new byte[rxDataAvailable];
                if (rxDataAvailable > 0)
                {
                    uint numBytesRead = 0;
                    if (ftdi.Read(dataBuffer, rxDataAvailable, ref numBytesRead) == FTDI.FT_STATUS.FT_OK)
                    {
                        if (numBytesRead == rxDataAvailable)
                        {
                            for (uint i = 0; i < rxDataAvailable; ++i)
                            {
                                byte nextByte = dataBuffer[i];
                                m_receivedPacket.Add(nextByte);

                                if (m_receivedPacket.Count() >= m_expectedReplyLength)
                                {
                                    ProcessRXBuffer(ref m_receivedPacket);
                                }

                            }
                        }
                    }
                }
            }
        }

    }
}